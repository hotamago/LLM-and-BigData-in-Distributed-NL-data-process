def convert_block_to_text(x: str, block_type: str):
    x = x.strip()
    # Check if ```json at the start and ``` at the end
    if x.startswith(f'```{block_type}') and x.endswith('```'):
        # Remove the ```json and ``` from the string
        x = x[3+len(block_type):-3]
        return x
    else:
        # Try to load the JSON string
        return x